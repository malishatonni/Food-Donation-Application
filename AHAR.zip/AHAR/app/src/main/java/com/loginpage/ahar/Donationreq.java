package com.loginpage.ahar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Donationreq extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donationreq);
    }
}